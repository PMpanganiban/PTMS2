import os
import json
import time
import subprocess
from datetime import datetime

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
JSON_PATH = os.path.join(BASE_DIR, 'monitor', 'static', 'router_status.json')
LOG_PATH = os.path.join(BASE_DIR, 'logs.txt')

# Devices to monitor
devices = {
    "Router1": "192.168.10.1",
    "Router2": "192.168.20.1",
    "Server":  "192.168.20.100"
}

# Helper: Ping a device
def ping(ip):
    try:
        subprocess.check_output(["ping", "-n" if os.name == "nt" else "-c", "1", ip],
                                stderr=subprocess.DEVNULL)
        return "Online"
    except subprocess.CalledProcessError:
        return "Offline"

# Read old status (if exists)
if os.path.exists(JSON_PATH):
    with open(JSON_PATH, 'r') as f:
        try:
            old_status = json.load(f)
        except:
            old_status = {}
else:
    old_status = {}

# New status after pinging
new_status = {}
changes = []

for name, ip in devices.items():
    status = ping(ip)
    new_status[name] = status

    old = old_status.get(name, "Unknown")
    if status != old:
        changes.append(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {name} changed from {old} to {status}")

# Save updated status to JSON
with open(JSON_PATH, 'w') as f:
    json.dump(new_status, f)

# Append changes to logs
if changes:
    with open(LOG_PATH, 'a') as log_file:
        for change in changes:
            log_file.write(change + '\n')

print("Status sync complete.")
