import os
import json
import subprocess
from datetime import datetime
from django.conf import settings
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse

@csrf_exempt
def dashboard(request):
    router_json_path = os.path.join(settings.BASE_DIR, "monitor", "static", "router_status.json")
    traffic_json_path = os.path.join(settings.BASE_DIR, "monitor", "static", "traffic_data.json")

    # Default values
    router1 = "Offline"
    router2 = "Offline"
    server = "Offline"
    traffic_data = {
        "router1_traffic": 0,
        "router2_traffic": 0,
        "server_traffic": 0,
        "timestamp": "Unknown"
    }

    try:
        with open(router_json_path, "r") as f:
            router_status = json.load(f)
            router1 = router_status.get("router1", "Offline")
            router2 = router_status.get("router2", "Offline")
            server = router_status.get("server", "Offline")
    except FileNotFoundError:
        pass

    try:
        with open(traffic_json_path, "r") as f:
            traffic_data = json.load(f)
    except FileNotFoundError:
        pass

    # Get current timestamp for "Last Checked"
    last_checked = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    return render(request, "dashboard.html", {
        "router1": router1,
        "router2": router2,
        "server": server,
        "last_checked": last_checked,
        "router_status": router_status if 'router_status' in locals() else {},
        "traffic_data": traffic_data,
    })

@csrf_exempt
def simulate_spike(request):
    traffic_file = os.path.join(settings.BASE_DIR, "monitor", "static", "traffic_data.json")
    try:
        traffic = {
            "router1_traffic": 125,
            "router2_traffic": 80,
            "server_traffic": 150,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        with open(traffic_file, "w") as f:
            json.dump(traffic, f)
        return JsonResponse({"success": True, "message": "Spike simulated."})
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)})
